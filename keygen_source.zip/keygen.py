# Ediz ve GPT-4 ile yap�lm��t�r.


import time
import random


def g(rolls):

    data = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    result = ""
    while rolls >= 1:
        c = random.choice(data)
        result += c
        rolls -= 1
    return result

# Interface
print("Multiple Gift Card Generator")
print("")


giftcards = [
    "Amazon", "Roblox", "Webkinz", "Fortnite", "IMVU",
    "Ebay", "Netflix", "iTunes", "Paypal", "Visa",
    "PokemonTGC", "Playstation", "Steam", "Xbox", "PlayStore",
    "Minecraft", "Google Play", "Apple Store", "Target", "Walmart",
    "Best Buy", "Starbucks", "GameStop", "Xbox Live", "Twitch",
    "Spotify", "PlayStation Plus", "Steam Wallet", "IKEA", "Subway",
    "Chipotle", "Dunkin Donuts", "Domino's", "Panda Express", "Barnes & Noble", "iTunes"
]


tt = input("\n" + "\n".join(giftcards) + "\n\n>").strip()
print("")
print("How many of them?")
n = int(input(">"))


formats = {
    "Minecraft": "xxxx-xxxx-xxxx",
    "Paypal": "xxxx-xxxx-xxxx",
    "Playstation": "xxxx-xxxx-xxxx",
    "Amazon": "xxxx-xxxx-xx",
    "Netflix": "xxxx-xxxx-xx",
    "Steam": "xxxx-xxxx-xxxxx",
    "Fortnite": "xxxxx-xxxx-xxxx",
    "Roblox": "xxx-xxx-xxxx",
    "iTunes": "xxxxxxxxxxxxxxxx",
    "Ebay": "xxxxxxxxxx",
    "IMVU": "xxxxxxxxxx",
    "Webkinz": "xxxxxxxx",
    "PokemonTGC": "xxx-xxxx-xxx-xxx",
    "PlayStore": "xxxx-xxxx-xxxx-xxxx-xxxx",
    "Xbox": "xxxxx-xxxxx-xxxxx-xxxxx-xxxxx",
    "Google Play": "xxxxxxxx-xxxx-xxxx-xxxx-xxxx",
    "Apple Store": "xxxxxxxxxxxx",
    "Target": "xxxx-xxxx-xxxx-xxxx",
    "Walmart": "xxxxxxxxxxxx",
    "Best Buy": "xxxx-xxxx-xxxx-xxxx",
    "Starbucks": "xxxxxxxxxxxx",
    "GameStop": "xxxx-xxxx-xxxx",
    "Xbox Live": "xxxx-xxxx-xxxx",
    "Twitch": "xxxx-xxxx-xxxx",
    "Spotify": "xxxx-xxxx-xxxx",
    "PlayStation Plus": "xxxx-xxxx-xxxx",
    "Steam Wallet": "xxxx-xxxx-xxxx-xxxx",
    "IKEA": "xxxx-xxxx-xxxx-xxxx",
    "Subway": "xxxx-xxxx-xxxx",
    "Chipotle": "xxxx-xxxx-xxxx",
    "Dunkin Donuts": "xxxx-xxxx-xxxx",
    "Domino's": "xxxx-xxxx-xxxx",
    "Panda Express": "xxxx-xxxx-xxxx",
    "Barnes & Noble": "xxxx-xxxx-xxxx",
    "iTunes": "xxxx-xxxx-xxxx"
}


if tt in formats:
    format_str = formats[tt]
    for _ in range(n):

        code = ''.join(g(1) if ch == 'x' else ch for ch in format_str)
        print(code)
else:
    print("Gift card type not recognized. Please try again.")

print("")
print("-----Generation completed-----")
time.sleep(360)
